# NetWorld - 跑酷文明复刻版 🏃‍♂️

<div align="center">
  <img src="game/icons/logo.png" alt="NetWorld Logo" width="200"/>
  
  ### 🎮 1:1 复刻 MC 跑酷文明 | 完全免费 | 3D体素风格
  
[![Deep Learning Corporation](https://img.shields.io/badge/Deep%20Learning%20Corporation-官方网站-2ea44f?style=flat-square)](https://deeplearning-corporation.github.io)
[![NetWorld](https://deeplearning-corporation.github.io/networld/index.html)]
</div>

---

## 📖 项目简介

**NetWorld** 是一个完全用 Java 实现的 3D 体素风格跑酷游戏，灵感来自 B 站热门视频 **【Evbo】MC跑酷文明大电影**。游戏完全复刻了视频中的阶层系统、食物机制、PVP 对决和神殿试炼等核心玩法。

### ✨ 游戏特色

- 🎯 **完整的阶层系统** - 从菜鸟到创世神，共7个阶层
- 🍗 **食物机制** - 跳远得鸡肉，跳高得牛肉，随时间消耗
- ⚔️ **PVP对决** - 与 NPC 进行回合制跑酷对决
- 🏛️ **神殿试炼** - 多层试炼挑战，晋升阶层
- 🌍 **体素世界** - 程序化生成的 3D 方块世界
- 🎨 **雾效渲染** - 真实的距离雾效
- 🎮 **流畅操作** - WASD移动，鼠标控制视角

---

## 🎯 阶层系统

| 阶层 | 中文 | 英文 | 所需食物 | 能力 |
|------|------|------|----------|------|
| 👶 菜鸟 | 菜鸟 | Rookie | 0 | 基础跳跃 |
| 🥈 专家 | 专家 | Pro | 50 | 跳远+1 |
| 🥇 大师 | 大师 | Master | 200 | 跳高+1 |
| 🏆 冠军 | 冠军 | Champion | 500 | 连击+2 |
| 🌟 传奇 | 传奇 | Legend | 1000 | 双倍食物 |
| ♾️ 不朽 | 不朽 | Immortal | 2000 | 免疫跌落 |
| ✨ 创世神 | 创世神 | Creator | 5000 | 创造平台 |

---

## 🚀 快速开始

### 方法1：使用启动器（推荐）

1. **下载启动器**  
   从 [Releases](https://github.com/yourusername/NetWorld/releases) 页面下载 `NetWorld Launcher.exe`

2. **运行启动器**  
   双击 `NetWorld Launcher.exe`，启动器会自动：
   - 检测系统 Java 环境
   - 如果没有 Java，自动下载 OpenJDK 17
   - 检测游戏文件
   - 启动游戏

3. **开始游戏**  
   点击 **"▶ 启动游戏"** 按钮

### 方法2：直接运行 JAR

```bash
# 需要 Java 17 或更高版本
java -jar game/game.jar